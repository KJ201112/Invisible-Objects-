Invisible Objects Geode mod source

Files:
- mod.json
- CMakeLists.txt
- src/main.cpp
- .github/workflows/build.yml
- about.md

Notes:
- This is source code, not a compiled .geode file.
- Build separately for Windows and Android with the matching Geode toolchain.
